<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onewave"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assume a logged-in user with ID 1
$userId = 1;

// Fetch all receipts for the user
$receiptsQuery = $conn->prepare("SELECT * FROM receipts WHERE user_id = ? ORDER BY created_at DESC");
$receiptsQuery->bind_param("i", $userId);
$receiptsQuery->execute();
$receiptsResult = $receiptsQuery->get_result();

$receipts = [];
while ($row = $receiptsResult->fetch_assoc()) {
    $receipts[] = $row;
}

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding-top: 70px;
        }
        h1 {
            text-align: center;
            color: #343a40;
            margin-bottom: 20px;
        }
        .purchase {
            border: 1px solid #dee2e6;
            border-radius: 5px; /* Reduce border radius */
            background-color: #ffffff;
            padding: 10px; /* Reduce padding */
            margin-bottom: 10px; /* Reduce margin */
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            max-width: 900px; /* Set max-width */
            margin: auto; /* Center within parent */
        }

        .purchase-item {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .purchase-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            margin-right: 15px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }
        .purchase-item p {
            margin: 5px 0;
        }
        .purchase-total {
            font-weight: bold;
            text-align: right;
            color: #495057;
        }
        .no-history {
            text-align: center;
            color: #6c757d;
        }
        .back-to-home {
            text-align: center;
            margin-top: 30px;
        }
        nav.navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar .nav-item select {
            width: auto;
        }
    </style>
</head>
<header>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <!-- Brand -->
            <a class="navbar-brand" href="home.php">OneWave</a>

            <!-- Toggler Button for Mobile View -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Collapsible Content -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <!-- Shop Category Dropdown -->
                    <li class="nav-item">
                        <select class="form-select" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                            <option value="">SELECT CATEGORY</option>
                            <option value="merch.php">MERCH</option>
                            <option value="dvd.php">DVD</option>
                            <option value="album.php">ALBUM</option>
                        </select>
                    </li>

                    <!-- Currency Selector -->
                    <li class="nav-item ms-3">
                        <select class="form-select" id="currencySelect">
                            <option value="USD" data-rate="1" data-symbol="$">USD</option>
                            <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                            <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                            <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                            <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                        </select>
                    </li>
                </ul>

                <!-- Right-side Actions -->
                <ul class="navbar-nav">
                    <!-- Shopping Cart Icon -->
                    <li class="nav-item">
                        <a href="cart.php" class="nav-link">
                            <i class="fas fa-shopping-cart" style="font-size: 25px; color: #17a2b8;"></i>
                        </a>
                    </li>

                    <!-- User Menu Dropdown -->
                    <li class="nav-item ms-3">
                        <select class="form-select" id="menuDropdown" onchange="if (this.value) window.location.href=this.value;">
                        <option value="">MY</option>
                        <option value="purchase.php">PURCHASES</option>
                        <option value="profile.php">PROFILE</option>
                        <option value="#" disabled><hr style="margin: 3px 0;"></option>
                        <option value="mainPage.php">LOG OUT</option>
                        <option value="#" disabled style="padding-bottom: 10px;"></option>
                        </select>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<body>
    <h1>Purchase History</h1>
    <div id="purchase-history-container">
        <?php if (count($receipts) === 0): ?>
            <p class="no-history">No purchase history available.</p>
        <?php else: ?>
            <?php foreach ($receipts as $receipt): ?>
                <div class="purchase">
                    <h3>Purchase Date: <?php echo htmlspecialchars($receipt['created_at']); ?></h3>
                    
                    <?php
                    // Fetch receipt items for each receipt
                    $receiptId = $receipt['receipt_id'];
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    $itemsQuery = $conn->prepare("SELECT * FROM receipt_items WHERE receipt_id = ?");
                    $itemsQuery->bind_param("i", $receiptId);
                    $itemsQuery->execute();
                    $itemsResult = $itemsQuery->get_result();

                    $items = [];
                    while ($item = $itemsResult->fetch_assoc()) {
                        $items[] = $item;
                    }

                    $conn->close();
                    $totalAmount = 0;
                    ?>
                    
                    <?php foreach ($items as $item): ?>
                        <div class="purchase-item">
                        <img src="<?php echo htmlspecialchars(!empty($item['image']) ? $item['image'] : 'https://via.placeholder.com/80'); ?>" 
                        alt="<?php echo htmlspecialchars($item['item_name']); ?>" 
                        class="product-img">

                            <div>
                                <p><?php echo htmlspecialchars($item['item_name']); ?></p>
                                <p>Quantity: <?php echo htmlspecialchars($item['quantity']); ?></p>
                                <p>$<?php echo number_format($item['item_price'] * $item['quantity'], 2); ?></p>
                            </div>
                        </div>
                        <?php $totalAmount += $item['item_price'] * $item['quantity']; ?>
                    <?php endforeach; ?>

                    <p class="purchase-total">Total: $<?php echo number_format($totalAmount, 2); ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="back-to-home">
        <a href="home.php" class="btn btn-primary">Back to Home</a>
    </div>
</body>
</html>
