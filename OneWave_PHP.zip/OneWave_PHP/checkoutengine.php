<?php
// Database connection parameters
$servername = "localhost";
$username = "root";  // Default username for local development
$password = "";      // Default password for local development
$dbname = "onewave"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data sent from the frontend (in JSON format)
$inputData = json_decode(file_get_contents('php://input'), true);

// Check if the checkout flag is set to true
if (isset($inputData['checkout']) && $inputData['checkout'] == true) {
    $selectedItems = $inputData['selected_items'];
    $paymentMethod = $inputData['payment_method'];
    $userId = 1;  // Example user ID (replace with actual logged-in user ID)

    // 1. Insert the receipt record into the database
    $totalAmount = 0;
    foreach ($selectedItems as $item) {
        $totalAmount += $item['price'] * $item['quantity'];
    }

    // Prepare and execute the INSERT query for the receipt
    $stmt = $conn->prepare("INSERT INTO receipts (user_id, total_amount, payment_method) VALUES (?, ?, ?)");
    $stmt->bind_param("ids", $userId, $totalAmount, $paymentMethod); // "i" for integer, "d" for double, "s" for string
    $stmt->execute();

    // Get the last inserted receipt ID
    $receiptId = $stmt->insert_id;

    // 2. Insert each receipt item into the receipt_items table
    foreach ($selectedItems as $item) {
        $itemTotal = $item['price'] * $item['quantity'];
        $stmt = $conn->prepare("INSERT INTO receipt_items (receipt_id, item_name, item_price, quantity, item_total) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isdis", $receiptId, $item['name'], $item['price'], $item['quantity'], $itemTotal);
        $stmt->execute();
    }

    // Return a success response
    echo json_encode(['success' => true, 'receipt_id' => $receiptId]);
} else {
    // If the checkout flag is not set or invalid data
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}

// Close the database connection
$conn->close();
?>
