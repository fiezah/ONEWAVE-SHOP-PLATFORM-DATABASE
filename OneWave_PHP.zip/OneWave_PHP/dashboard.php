<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneWave Shop - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f5f5f5;
        }

        .dashboard-header {
            padding: 1rem;
            background-color: #17a2b8;
            color: #fff;
            text-align: center;
        }

        .dashboard-header h1 {
            margin: 0;
            font-size: 1.8rem;
        }

        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 1.2rem;
        }

        .main-content {
            margin: 1.5rem auto;
        }

        .stat-card {
            text-align: center;
        }

        .stat-card .stat-icon {
            font-size: 2.5rem;
            color: #17a2b8;
        }

        .recent-activity li {
            list-style: none;
            border-bottom: 1px solid #ddd;
            padding: 0.5rem 0;
        }

        .recent-activity li:last-child {
            border-bottom: none;
        }

        .btn-primary {
            background-color: #17a2b8;
            border: none;
        }
		
		.btn-primary:hover {
			background-color: #138496;
		}
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <header class="dashboard-header">
        <h1>Welcome to the OneWave Dashboard</h1>
    </header>

    <!-- Main Dashboard Content -->
    <div class="container main-content">
        <div class="row">
            <!-- Stat Cards -->
            <div class="col-md-3">
                <div class="card p-3 stat-card">
                    <i class="fas fa-users stat-icon"></i>
                    <h5 class="card-title mt-2">Users</h5>
                    <p class="card-text">450 Active Users</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 stat-card">
                    <i class="fas fa-chart-line stat-icon"></i>
                    <h5 class="card-title mt-2">Revenue</h5>
                    <p class="card-text">$8,245 This Month</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 stat-card">
                    <i class="fas fa-shopping-cart stat-icon"></i>
                    <h5 class="card-title mt-2">Orders</h5>
                    <p class="card-text">1,250 Total Orders</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 stat-card">
                    <i class="fas fa-boxes stat-icon"></i>
                    <h5 class="card-title mt-2">Products</h5>
                    <p class="card-text">300 Items in Stock</p>
                </div>
            </div>
        </div>

        <!-- Recent Activity and Quick Links -->
        <div class="row mt-4">
            <!-- Recent Activity -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Recent Activity</h5>
                        <ul class="recent-activity">
                            <li><i class="fas fa-user-plus"></i> New user registered: louisme</li>
                            <li><i class="fas fa-shopping-cart"></i> New order placed: Order #30112020</li>
                            <li><i class="fas fa-box-open"></i> Product added: "New Album"</li>
                            <li><i class="fas fa-comments"></i> Support ticket raised by Sarah</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Quick Links</h5>
                        <div class="d-flex flex-column">
                            <a href="adminmerch.php" class="btn btn-primary mb-2">Manage Merch</a>
                            <a href="admindvd.php" class="btn btn-primary mb-2">Manage DVDs</a>
                            <a href="adminalbum.php" class="btn btn-primary mb-2">Manage Albums</a>
							<a href="signingUp.php" class="btn btn-primary mb-2">Admin Log Out</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
	<footer class="bg-light text-dark mt-5">
	  <div class="container py-4">
		<div class="row">
		  <!-- Address Section -->
		  <div class="col-md-4">
			<h6>Company Information</h6>
			<address>
			  <strong>OneWave</strong><br>
			  6/1 Capricorn Street, <br>
			  Kuala Lumpur, Seoul, 56100<br>
			  <abbr title="Phone">P:</abbr> (123) 456-7890<br>
			  <abbr title="Email">E:</abbr> support@ohneulwave.com
			</address>
		  </div>

		  <!-- Useful Links -->
		  <div class="col-md-4">
			<h6>Useful Links</h6>
			<ul class="list-unstyled">
			  <li><a href="#">Terms of Service</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">FAQ</a></li>
			  <li><a href="#">Contact Us</a></li>
			</ul>
		  </div>

		  <!-- Social Media Links -->
		  <div class="col-md-4">
			<h6>Follow Us</h6>
			<ul class="list-unstyled">
			  <li><a href="https://www.instagram.com/twistntreatdotcom/">Instagram</a></li>
			  <li><a href="https://twitter.com">Twitter</a></li> <!-- Corrected Twitter link -->
			  <li><a href="https://facebook.com">Facebook</a></li> <!-- Corrected Facebook link -->
			</ul>
		  </div>
		</div>

		<div class="text-center mt-4">
		  <p class="mb-0">© 2024 OneWave. All rights reserved.</p>
		</div>
	  </div>
	</footer>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
