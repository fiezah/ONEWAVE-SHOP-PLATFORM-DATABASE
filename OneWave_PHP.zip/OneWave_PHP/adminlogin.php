<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .form-container {
            max-width: 700px;
            margin: 100px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .form-container h1 {
            font-family: 'Pacifico', cursive;
            font-size: 40px;
            font-weight: 600;
            margin-bottom: 20px;
            margin-top: 40px;
            color: #17a2b8;
        }
        .form-container h4 {
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
            font-weight: bold;
        }
        .form-container input[type="text"],
        .form-container input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 12px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #138496;
        }
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 20px 0;
        }
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #ccc;
        }
        .divider::before {
            margin-right: 10px;
        }
        .divider::after {
            margin-left: 10px;
        }
        .form-container a {
            color: #17a2b8;
            text-decoration: none;
            font-size: 14px;
        }
        .form-container a:hover {
            text-decoration: underline;
        }
        footer {
            background-color: #17a2b8;
            text-align: center;
            padding: 20px;
            margin-top: 50px;
            color: white;
            font-size: 17px;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>OneWave</h1>
    <h4>Login to your OneWave account</h4>
    <!-- Update the form to submit data to loginengine.php -->
    <form action="adminloginengine.php" method="POST">
        <label for="email">Email</label><br>
        <input type="text" id="email" name="email" required><br><br>

        <label for="password">Password</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <button type="submit" name="login">Login</button>
    </form>
    
    <div class="info">
        Don't have an account? <a href="adminsignup.php">Sign up here</a>
    </div>
</div>

<footer>
    <p>© 2024 OneWave. All rights reserved. Privacy Policy | Terms of Service</p>
</footer>

</body>
</html>
