<?php
// Include the database connection
include 'db_connection.php';

// Check if form data is sent via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the data from the form
    $username = $_POST['username'];
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $password = $_POST['password'];  // Capture the plain password

    // SQL query to insert data into the user table (without password hashing)
    $sql = "INSERT INTO user (username, user_name, email, phone, gender, password) 
            VALUES ('$username', '$user_name', '$email', '$phone', '$gender', '$password')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New user created successfully.');</script>";
        header("Location: userlogin.php");
        exit; // Make sure to stop execution after redirection
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }

    // Close the database connection
    $conn->close();
}
?>
