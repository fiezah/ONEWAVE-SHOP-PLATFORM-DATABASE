<?php
// Include the database connection
include 'db_connection.php';

// Check if form data is sent via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the data from the form
    $admin_name = $_POST['admin_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];  // Capture the plain password

    // SQL query to insert data into the admin table (without password hashing)
    $sql = "INSERT INTO admin (admin_name, email, password) 
            VALUES ('$admin_name', '$email', '$password')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New admin user created successfully.');</script>";
        header("Location: adminlogin.php");
        exit; // Make sure to stop execution after redirection
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }

    // Close the database connection
    $conn->close();
}
?>
