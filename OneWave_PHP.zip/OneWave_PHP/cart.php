<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneWave Shopping Cart</title>
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            padding-top: 70px; /* Prevent content overlap with navbar */
        }
        nav.navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar .nav-item select {
            width: auto;
        }

        .cart-container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .cart-header {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 0;
        }
        .cart-item:last-child {
            border-bottom: none;
        }
        .cart-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }
        .cart-item-details {
            flex-grow: 1;
            margin-left: 15px;
        }
        .cart-item-title {
            font-size: 16px;
            margin: 0;
        }
        .cart-item-price {
            font-size: 14px;
            color: #666;
        }
        .remove-btn {
            color: #ff0000;
            cursor: pointer;
        }
        .total-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }
        .checkout-btn {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .checkout-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<header>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <!-- Brand -->
            <a class="navbar-brand" href="home.php">OneWave</a>

            <!-- Toggler Button for Mobile View -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Collapsible Content -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <!-- Shop Category Dropdown -->
                    <li class="nav-item">
                        <select class="form-select" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                            <option value="">SELECT CATEGORY</option>
                            <option value="merch.php">MERCH</option>
                            <option value="dvd.php">DVD</option>
                            <option value="album.php">ALBUM</option>
                        </select>
                    </li>

                    <!-- Currency Selector -->
                    <li class="nav-item ms-3">
                        <select class="form-select" id="currencySelect">
                            <option value="USD" data-rate="1" data-symbol="$">USD</option>
                            <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                            <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                            <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                            <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                        </select>
                    </li>
                </ul>

                <!-- Right-side Actions -->
                <ul class="navbar-nav">
                    <!-- Shopping Cart Icon -->
                    <li class="nav-item">
                        <a href="cart.php" class="nav-link">
                            <i class="fas fa-shopping-cart" style="font-size: 25px; color: #17a2b8;"></i>
                        </a>
                    </li>

                    <!-- User Menu Dropdown -->
                    <li class="nav-item ms-3">
                        <select class="form-select" id="menuDropdown" onchange="if (this.value) window.location.href=this.value;">
                        <option value="">MY</option>
                        <option value="purchase.php">PURCHASES</option>
                        <option value="profile.php">PROFILE</option>
                        <option value="#" disabled><hr style="margin: 3px 0;"></option>
                        <option value="mainPage.php">LOG OUT</option>
                        <option value="#" disabled style="padding-bottom: 10px;"></option>
                        </select>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<body>

<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onewave";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$sql = "
    SELECT id, name, price, image, 'merch' AS category FROM merch
    UNION ALL
    SELECT id, name, price, image, 'dvd' AS category FROM dvd
    UNION ALL
    SELECT id, name, price, image, 'album' AS category FROM album
";
$result = $conn->query($sql);

// Close connection after fetching
$conn->close();
?>

<div class="cart-container">
    <div class="cart-header">Your Shopping Cart</div>
    <div id="cart-items">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($item = $result->fetch_assoc()): ?>
                <div class="cart-item" data-id="<?php echo $item['id']; ?>" data-price="<?php echo $item['price']; ?>">
                    <img src="<?php echo $item['image']; ?>" alt="Product Image">
                    <div class="cart-item-details">
                        <p class="cart-item-title"><?php echo $item['name']; ?></p>
                        <p class="cart-item-price">Price: $<?php echo number_format($item['price'], 2); ?></p>
                        <input type="number" class="form-control quantity-input" value="1" min="1" style="width: 60px;">
                    </div>
                    <i class="fas fa-trash remove-btn"></i>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Your cart is empty!</p>
        <?php endif; ?>
    </div>
    <div class="total-container">
        <span>Total: $<span id="total-amount">0.00</span></span>
        <button class="checkout-btn">Checkout</button>
    </div>
</div>

<script src="path/to/currency.js" defer></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.getElementById('cart-items');
    const totalAmountEl = document.getElementById('total-amount');
    const checkoutBtn = document.querySelector('.checkout-btn'); // The checkout button

    // Fetch cart from localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Function to render cart items
    function renderCart() {
        cartItemsContainer.innerHTML = '';  // Clear current cart
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p>Your cart is empty!</p>';
        } else {
            cart.forEach(item => {
                const cartItem = document.createElement('div');
                cartItem.classList.add('cart-item');
                cartItem.dataset.id = item.id;
                cartItem.dataset.price = item.price;

                cartItem.innerHTML = `
                    <img src="${item.image}" alt="${item.name}" style="width: 80px; height: 80px;">
                    <div>
                        <h5>${item.name}</h5>
                        <p>$${item.price.toFixed(2)} x <input type="number" class="quantity-input" value="${item.quantity}" min="1"></p>
                    </div>
                    <div>
                        <input type="checkbox" class="select-item" data-id="${item.id}" ${item.selected ? 'checked' : ''}>
                        <span>Select for checkout</span>
                    </div>
                    <button class="btn btn-danger remove-btn">Remove</button>
                `;
                cartItemsContainer.appendChild(cartItem);
            });
        }
        calculateTotal();
    }

    // Calculate total price of selected items
    function calculateTotal() {
        let total = 0;
        document.querySelectorAll('.cart-item').forEach(item => {
            const price = parseFloat(item.dataset.price);
            const quantity = parseInt(item.querySelector('.quantity-input').value, 10);
            const isSelected = item.querySelector('.select-item').checked;
            if (isSelected) {
                total += price * quantity;
            }
        });
        totalAmountEl.textContent = total.toFixed(2);
    }

    // Remove item from cart
    cartItemsContainer.addEventListener('click', event => {
        if (event.target.classList.contains('remove-btn')) {
            const cartItem = event.target.closest('.cart-item');
            const itemId = cartItem.dataset.id;
            cart = cart.filter(item => item.id !== itemId);  // Remove item from cart
            localStorage.setItem('cart', JSON.stringify(cart));  // Update localStorage
            renderCart();  // Re-render cart
        }
    });

    // Listen for quantity changes
    cartItemsContainer.addEventListener('input', event => {
        if (event.target.classList.contains('quantity-input')) {
            const cartItem = event.target.closest('.cart-item');
            const itemId = cartItem.dataset.id;
            const newQuantity = parseInt(event.target.value, 10);

            // Update cart data
            const itemIndex = cart.findIndex(item => item.id === itemId);
            if (itemIndex !== -1) {
                cart[itemIndex].quantity = newQuantity;
                localStorage.setItem('cart', JSON.stringify(cart));  // Update localStorage
                calculateTotal();
            }
        }
    });

    // Handle item selection (checkbox)
    cartItemsContainer.addEventListener('change', event => {
        if (event.target.classList.contains('select-item')) {
            const itemId = event.target.dataset.id;
            const itemIndex = cart.findIndex(item => item.id === itemId);
            if (itemIndex !== -1) {
                cart[itemIndex].selected = event.target.checked;
                localStorage.setItem('cart', JSON.stringify(cart));  // Update localStorage
                calculateTotal();
            }
        }
    });

    // Proceed to checkout with selected items
    checkoutBtn.addEventListener('click', () => {
    // Get selected items
    const selectedItems = [];
    document.querySelectorAll('.cart-item').forEach(item => {
        const checkbox = item.querySelector('.select-item');
        if (checkbox.checked) {
            const itemId = item.dataset.id;
            const itemPrice = item.dataset.price;
            const quantity = item.querySelector('.quantity-input').value;

            selectedItems.push({
                id: itemId,
                price: itemPrice,
                quantity: quantity
            });
        }
    });

    if (selectedItems.length > 0) {
        // Store the selected items in localStorage
        localStorage.setItem('selectedCartItems', JSON.stringify(selectedItems));
        // Redirect to checkout page
        window.location.href = 'checkout.php';  // Or 'checkout.html' if you are not using PHP
    } else {
        alert('Please select at least one item to checkout.');
    }
});

    // Initialize cart on page load
    renderCart();
});
</script>

</body>
</html>
