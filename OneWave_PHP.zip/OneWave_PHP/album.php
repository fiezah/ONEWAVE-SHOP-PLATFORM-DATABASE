<?php
// Database credentials
$servername = "localhost";
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "onewave"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the `album` table
$sql = "SELECT id, name, price, image FROM album";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OneWave Shop - Album Page</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<header>

    <!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-navbar">
    <div class="container">
        <a class="navbar-brand" href="home.php">OneWave</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <!-- Shop Select Dropdown -->
                <li class="nav-item">
                    <form class="form-inline my-2 my-lg-0 ml-3">
                        <select class="form-control" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                            <option value="">SELECT CATEGORY</option>
                            <option value="merch.php">MERCH</option>
                            <option value="dvd.php">DVD</option>
                            <option value="album.php">ALBUM</option>
                        </select>
                    </form>
                </li>
                
                <!-- Currency Select Dropdown -->
                <li class="nav-item">
                    <form class="form-inline my-2 my-lg-0 ml-3">
                        <select class="form-control" id="currencySelect">
                            <option value="USD" data-rate="1" data-symbol="$">USD</option>
                            <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                            <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                            <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                            <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                        </select>
                    </form>
                </li>
            </ul>

			<!-- Shopping Cart Icon -->
			<a href="cart.php" class="mr-3">
                    <i class="fas fa-shopping-cart" style="font-size: 24px; color: #17a2b8;"></i>
                </a>

            <!-- Menu Dropdown -->
            <form class="form-inline my-2 my-lg-0 ml-3">
                <select class="form-control" id="menuDropdown" onchange="if (this.value) window.location.href=this.value;">
                    <option value="">MY</option>
                    <option value="purchase.php">PURCHASES</option>
                    <option value="profile.php">PROFILE</option>
					<option value="#" disabled><hr style="margin: 3px 0;"></option>
                    <option value="mainPage.php">LOG OUT</option>
					<option value="#" disabled style="padding-bottom: 10px;"></option>
                </select>
            </form>
        </div>
    </div>
</nav>

</header>
<body>
    <div class="container mt-5">
        <div class="row">
            <?php
            // Check if there are results, and loop through each row to display each product
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '
                    <div class="col-md-4 mb-4">
                        <div class="product-card">
                            <img src="' . htmlspecialchars($row['image']) . '" alt="' . htmlspecialchars($row['name']) . '" class="product-img">
                            <div class="product-info">
                                <h5 class="product-title">' . htmlspecialchars($row['name']) . '</h5>
                                <p class="product-price" data-original-price="' . $row['price'] . '">$' . number_format($row['price'], 2) . '</p>
                                <button class="btn add-to-cart" data-id="' . $row['id'] . '" data-name="' . htmlspecialchars($row['name']) . '" data-price="' . number_format($row['price'], 2) . '">Add to Cart</button>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo "<p>No products found.</p>";
            }
            // Close the database connection
            $conn->close();
            ?>
        </div>
    </div>

	<!-- Footer -->
	<footer class="bg-light text-dark mt-5">
	  <div class="container py-4">
		<div class="row">
		  <!-- Address Section -->
		  <div class="col-md-4">
			<h6>Company Information</h6>
			<address>
			  <strong>OneWave</strong><br>
			  6/1 Capricorn Street, <br>
			  Kuala Lumpur, Seoul, 56100<br>
			  <abbr title="Phone">P:</abbr> (123) 456-7890<br>
			  <abbr title="Email">E:</abbr> support@ohneulwave.com
			</address>
		  </div>

		  <!-- Useful Links -->
		  <div class="col-md-4">
			<h6>Useful Links</h6>
			<ul class="list-unstyled">
			  <li><a href="#">Terms of Service</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">FAQ</a></li>
			  <li><a href="#">Contact Us</a></li>
			</ul>
		  </div>

		  <!-- Social Media Links -->
		  <div class="col-md-4">
			<h6>Follow Us</h6>
			<ul class="list-unstyled">
			  <li><a href="https://www.instagram.com/twistntreatdotcom/">Instagram</a></li>
			  <li><a href="https://twitter.com">Twitter</a></li> <!-- Corrected Twitter link -->
			  <li><a href="https://facebook.com">Facebook</a></li> <!-- Corrected Facebook link -->
			</ul>
		  </div>
		</div>

		<div class="text-center mt-4">
		  <p class="mb-0">© 2024 OneWave. All rights reserved.</p>
		</div>
	  </div>
	</footer>
     
    <script src="path/to/currency.js" defer></script>
	<script>
		// Currency selector
		document.getElementById('currencySelect').addEventListener('change', function() {
			const selectedOption = this.options[this.selectedIndex];
            const rate = parseFloat(selectedOption.getAttribute('data-rate'));
            const symbol = selectedOption.getAttribute('data-symbol');
            const priceElements = document.querySelectorAll('.product-price');
			
			priceElements.forEach(function(element) {
				const originalPrice = parseFloat(element.getAttribute('data-original-price'));
                const convertedPrice = (originalPrice * rate).toFixed(2);
                element.textContent = `${symbol}${convertedPrice}`;
            });
        });
		
		function filterProducts() {
		// Get the search term from the input field, converted to lowercase
		const searchTerm = document.getElementById('search-bar').value.toLowerCase();

		// Select all product cards
		const productCards = document.querySelectorAll('.product-card');

		// Loop through each product card to check if it matches the search term
		productCards.forEach(card => {
			// Get the product title text, converted to lowercase
			const productName = card.querySelector('.product-title').textContent.toLowerCase();

			// Show or hide the card based on whether the product name includes the search term
			if (productName.includes(searchTerm)) {
				card.parentElement.style.display = 'block'; // Show matching products
			} else {
				card.parentElement.style.display = 'none'; // Hide non-matching products
			}
		});
	}

		
		// Add to cart function
		document.querySelectorAll('.add-to-cart').forEach(function(button) {
			button.addEventListener('click', function() {
				// Retrieve product details from the button's data attributes
				const productId = button.getAttribute('data-id');
				const productTitle = button.getAttribute('data-name');
				const productPrice = parseFloat(button.getAttribute('data-price'));
				// Find the image element and get its source
				const productImage = button.closest('.product-card').querySelector('.product-img').src;
				// Retrieve existing cart or initialize as an empty array
				const cart = JSON.parse(localStorage.getItem('cart')) || [];
				// Check if the item already exists in the cart
				const existingItem = cart.find(item => item.id === productId);
				if (existingItem) {
					// If item exists, increase the quantity
					existingItem.quantity += 1;
				} else {
					// If item does not exist, add a new item to the cart
					const newItem = {
						id: productId,
						name: productTitle,
						price: productPrice,
						image: productImage,
						quantity: 1
					};
					cart.push(newItem);
				}
				// Save the updated cart to localStorage
				localStorage.setItem('cart', JSON.stringify(cart));
				
				alert('Added to cart: ' + productTitle);
			});
		});
		
		// Responsive navbar toggle
		$(function () {
			$('[data-toggle="collapse"]').click(function () {
				$(this).toggleClass('active');
			});
		});
		
		// Form validation
		document.querySelector('form').addEventListener('submit', function(event) {
			const searchInput = document.querySelector('input[type="search"]');
			if (!searchInput.value) {
				alert('Please enter a search term.');
				event.preventDefault();
			}
		});
	</script>
  </body>
</html>

<style>

/* CSS Styles */

body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.row {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.col-md-4 {
    flex: 0 0 32%;
    box-sizing: border-box;
    margin-bottom: 20px;
}

.product-card {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease-in-out;
}

.product-card:hover {
    transform: translateY(-5px);
}

.product-img {
    width: 100%;
    height: auto;
    max-height: 200px;
    object-fit: contain;
    border-radius: 8px;
}

.product-info {
    text-align: center;
    margin-top: 15px;
}

.product-title {
    font-size: 18px;
    color: #333;
    margin: 10px 0;
}

.product-price {
    font-size: 16px;
    color: #666;
}

.btn {
    display: inline-block;
    padding: 10px 20px;
    font-size: 14px;
    color: #fff;
    background-color: #17a2b8;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-transform: uppercase;
    transition: background-color 0.3s ease;
    margin-top: 10px;
}

.btn:hover {
    background-color: #138496;
}

.mt-5 {
    margin-top: 3rem;
}

.mb-4 {
    margin-bottom: 1.5rem;
}

</style>