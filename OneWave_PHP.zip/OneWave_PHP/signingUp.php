<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Options</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Signup</h1>
        <p>Choose your role to sign up:</p>
        <div class="button-container">
            <a href="adminsignup.php" class="button">Admin Signup</a>
            <a href="usersignup.php" class="button">User Signup</a>
        </div>
    </div>
</body>
</html>

<style>
/* style.css */
body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color: #f4f4f4;
}

.container {
    text-align: center;
}

.button-container {
    margin-top: 20px;
}

.button {
    display: inline-block;
    padding: 15px 30px;
    font-size: 16px;
    color: white;
    background-color: #17a2b8;
    text-decoration: none;
    border-radius: 5px;
    margin: 10px;
    transition: background-color 0.3s;
}

.button:hover {
    background-color: #138496;
}
</style>