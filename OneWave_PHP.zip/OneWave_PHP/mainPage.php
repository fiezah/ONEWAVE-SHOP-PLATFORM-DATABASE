<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OneWave Project</title>
    <!-- Bootstrap -->
	 <style>
		.shop-footer {
			text-align: center;
			padding: 10px 0;
			border-top: 2px solid #e9ecef;
			display: flex;              /* Use flexbox */
			justify-content: center;    /* Center items horizontally */
			gap: 10px;                  /* Add spacing between the buttons */
		}
		.go-shopping {
			display: inline-block;
			background-color: #17a2b8; /* Same color as Back to Home button */
			color: white;
			padding: 10px 20px;
			font-size: 16px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			margin-top: 10px; /* Add space above the button */
		}

		.go-shopping:hover {
			background-color: #138496; /* Same hover effect as Back to Home */
		}
	</style>
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
</head>

<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-navbar">
        <div class="container">
            <a class="navbar-brand" href="mainPage.html">OneWave</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <!-- Shop Select Dropdown -->
                        <form class="form-inline my-2 my-lg-0 ml-3">
                            <select class="form-control" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                                <option value="">Select Shop</option>
                                <option value="help.php">MERCH</option>
                                <option value="help.php">DVD</option>
                                <option value="help.php">ALBUM</option>
                            </select>
                        </form>
                    </li>
                    <li class="nav-item">
                        <!-- Currency Select Dropdown -->
                        <form class="form-inline my-2 my-lg-0 ml-3">
                            <select class="form-control" id="currencySelect">
                                <option value="USD" data-rate="1" data-symbol="$">USD</option>
                                <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                                <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                                <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                                <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                            </select>
                        </form>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
					<button class="btn btn-outline-info my-2 my-sm-0 mr-2" type="button" onclick="window.location.href='help.php'">Help</button>
					<button class="btn btn-outline-info my-2 my-sm-0 mr-2" type="button" onclick="window.location.href='login.php'">Log In</button>
					<button class="btn btn-outline-info my-2 my-sm-0 mr-2" type="button" onclick="window.location.href='signingUp.php'">Sign Up</button>
				</form>
			</div>
        </div>
    </nav>
</header>

<body>

<div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleControls" data-slide-to="1"></li>
                        <li data-target="#carouselExampleControls" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="images/HOME_BANNER.png" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/HOME_BANNER2.png" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/HOME_BANNER3.png" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
        <hr>
    </div>

	<div class="container">
      <div class="row">
        <div class="col-4">
          <div class="row">
            <div class="col-2"><img class="rounded-circle" alt="Free Shipping" src="images/icon.png"></div>
            <div class="col-lg-6 col-10 ml-1">
              <h4>Free Shipping</h4>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="row">
            <div class="col-2"><img class="rounded-circle" alt="Free Shipping" src="images/icon2.png"></div>
            <div class="col-lg-6 col-10 ml-1">
              <h4>Free Returns</h4>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="row">
            <div class="col-2"><img class="rounded-circle" alt="Free Shipping" src="images/icon3.png"></div>
            <div class="col-lg-6 col-10 ml-1">
              <h4>Low Prices</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
    <hr>
    <h2 class="text-center">RECOMMENDED PRODUCTS</h2>
    <hr>
    <div class="mt-5">
			<div class="row">
				<!-- Product 1 -->
				<div class="col-md-4 mb-4">
					<div class="product-card p-3">
						<img src="images/HOME_DISPLAY.png" alt="RINGER T-SHIRT" class="product-img">
						<div class="product-info text-center mt-3">
							<h5 class="product-title">RINGER T-SHIRT</h5>
							<p class="product-price" data-original-price="24.44">$24.44</p>
						</div>
					</div>
				</div>

				<!-- Product 2 -->
				<div class="col-md-4 mb-4">
					<div class="product-card p-3">
						<img src="images/HOME_DISPLAY2.png" alt="THE 1ST ALBUM METAMORPHIC" class="product-img">
						<div class="product-info text-center mt-3">
							<h5 class="product-title">THE 1ST ALBUM METAMORPHIC</h5>
							<p class="product-price" data-original-price="44.36">$44.36</p>
						</div>
					</div>
				</div>

				<!-- Product 3 -->
				<div class="col-md-4 mb-4">
					<div class="product-card p-3">
						<img src="images/HOME_DISPLAY3.png" alt="PICES OF MEMORIES" class="product-img">
						<div class="product-info text-center mt-3">
							<h5 class="product-title">PICES OF MEMORIES</h5>
							<p class="product-price" data-original-price="12.29">$12.29</p>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>

	<div class="shop-footer">
		<button class="go-shopping" onclick="window.location.href='help.php'">Go Shopping</button> <!-- New button -->
	</div>


	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

	<!-- Footer -->
	<footer class="bg-light text-dark mt-5">
	  <div class="container py-4">
		<div class="row">
		  <!-- Address Section -->
		  <div class="col-md-4">
			<h6>Company Information</h6>
			<address>
			  <strong>OneWave</strong><br>
			  6/1 Capricorn Street, <br>
			  Kuala Lumpur, Seoul, 56100<br>
			  <abbr title="Phone">P:</abbr> (123) 456-7890<br>
			  <abbr title="Email">E:</abbr> support@ohneulwave.com
			</address>
		  </div>

		  <!-- Useful Links -->
		  <div class="col-md-4">
			<h6>Useful Links</h6>
			<ul class="list-unstyled">
			  <li><a href="help.html">Terms of Service</a></li>
			  <li><a href="help.html">Privacy Policy</a></li>
			  <li><a href="help.html">FAQ</a></li>
			  <li><a href="help.html">Contact Us</a></li>
			</ul>
		  </div>

		  <!-- Social Media Links -->
		  <div class="col-md-4">
			<h6>Follow Us</h6>
			<ul class="list-unstyled">
			  <li><a href="https://www.instagram.com/twistntreatdotcom/">Instagram</a></li>
			  <li><a href="https://twitter.com">Twitter</a></li> <!-- Corrected Twitter link -->
			  <li><a href="https://facebook.com">Facebook</a></li> <!-- Corrected Facebook link -->
			</ul>
		  </div>
		</div>

		<div class="text-center mt-4">
		  <p class="mb-0">© 2024 OneWave. All rights reserved.</p>
		</div>
	  </div>
	</footer>

	<!-- My custom JavaScript -->
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

	<script>
		// Currency selector
		document.getElementById('currencySelect').addEventListener('change', function() {
			const selectedOption = this.options[this.selectedIndex];
            const rate = parseFloat(selectedOption.getAttribute('data-rate'));
            const symbol = selectedOption.getAttribute('data-symbol');
            const priceElements = document.querySelectorAll('.product-price');
			
			priceElements.forEach(function(element) {
				const originalPrice = parseFloat(element.getAttribute('data-original-price'));
                const convertedPrice = (originalPrice * rate).toFixed(2);
                element.textContent = `${symbol}${convertedPrice}`;
            });
        });
		
		// Add to cart function
		document.querySelectorAll('.add-to-cart').forEach(function(button) {
			button.addEventListener('click', function() {
				// Retrieve product details from the button's data attributes
				const productId = button.getAttribute('data-id');
				const productTitle = button.getAttribute('data-name');
				const productPrice = parseFloat(button.getAttribute('data-price'));
				// Find the image element and get its source
				const productImage = button.closest('.product-card').querySelector('.product-img').src;
				// Retrieve existing cart or initialize as an empty array
				const cart = JSON.parse(localStorage.getItem('cart')) || [];
				// Check if the item already exists in the cart
				const existingItem = cart.find(item => item.id === productId);
				if (existingItem) {
					// If item exists, increase the quantity
					existingItem.quantity += 1;
				} else {
					// If item does not exist, add a new item to the cart
					const newItem = {
						id: productId,
						name: productTitle,
						price: productPrice,
						image: productImage,
						quantity: 1
					};
					cart.push(newItem);
				}
				// Save the updated cart to localStorage
				localStorage.setItem('cart', JSON.stringify(cart));
				
				alert('Added to cart: ' + productTitle);
			});
		});
		
		// Responsive navbar toggle
		$(function () {
			$('[data-toggle="collapse"]').click(function () {
				$(this).toggleClass('active');
			});
		});
		
		// Form validation
		document.querySelector('form').addEventListener('submit', function(event) {
			const searchInput = document.querySelector('input[type="search"]');
			if (!searchInput.value) {
				alert('Please enter a search term.');
				event.preventDefault();
			}
		});
	</script>
  </body>
</html>

<style>
	.shadow-navbar {
		box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
		z-index: 1000; 
	}
</style>
