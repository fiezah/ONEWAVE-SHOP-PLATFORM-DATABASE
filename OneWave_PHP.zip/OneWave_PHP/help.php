<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support - OneWave</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            /* Gradient Background */
            background: #CC95C0;
            background: -webkit-linear-gradient(to top, #7AA1D2, #DBD4B4, #CC95C0);
            background: linear-gradient(to top, #7AA1D2, #DBD4B4, #CC95C0);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .custom-heading {
            margin-bottom: 0.5rem;
            font-size: 1.0rem;
        }

        .search-section {
            padding: 60px 0;
        }

        .search-bar {
            max-width: 600px;
            margin: auto;
        }
		
		.link-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-size: 1.25rem; /* Adjust size to match your design */
}

.link-under-search {
    text-decoration: none;
    color: #17a2b8; /* Color to match your design */
    font-weight: 500;
}

.link-under-search:hover {
    text-decoration: underline;
}


        .faq-container {
            max-width: 600px;
            margin: auto;
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 2rem;
        }

        .faq-item {
            margin-bottom: 1.5rem;
        }

        .faq-item h3 {
            font-size: 1.1rem;
            color: #17a2b8;
            cursor: pointer;
            margin: 0;
            padding: 0.5rem 0;
            border-bottom: 1px solid #ddd;
        }

        .faq-item p {
            display: none;
            margin: 0;
            padding: 0.5rem 0;
            color: #555;
        }

        .faq-item p.show {
            display: block;
        }

        footer {
            background-color: #7AA1D2;
            color: white;
            text-align: center;
            padding: 1rem;
            position: relative;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #7AA1D2;
        }

        footer a {
            color: #ffffff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">OneWave</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="mainPage.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Account</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="userlogin.php">Log in to manage account</a></li>
                            <li><a class="dropdown-item" href="#">Account overview</a></li>
                            <li><a class="dropdown-item" href="#">Payment</a></li>
							<li><a class="dropdown-item" href="#">Security and privacy</a></li>
							<div class="dropdown-divider"></div>
							<li><a class="dropdown-item" href="usersignup.php">Sign up</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Search Section -->
    <div class="search-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h4 class="custom-heading">OneWave Support</h4>
                    <h1>How can we help you?</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="search-bar mt-4">
                        <input type="text" class="form-control form-control-lg" placeholder="Search...">
                    </div>
					<div class="mt-3">
						<div class="link-container">
							<a href="userlogin.php" class="link-under-search">Log In</a>
							<span>for faster help</span>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ Section -->
    <div class="faq-container">
        <div class="container">
            <div class="faq-item">
                <h3>What is OneWave?</h3>
                <p>OneWave is an online store for official merchandise of k-pop artists from associated labels. It features a range of fan products like albums and clothing, with a focus on an easy-to-use and visually appealing design.</p>
            </div>
            <div class="faq-item">
                <h3>How do I reset my password?</h3>
                <p>If you've forgotten your password, you can reset it by clicking on the "Forgot Password" link on the login page and following the instructions sent to your email.</p>
            </div>
            <div class="faq-item">
                <h3>How do I check the status of my order?</h3>
                <p>You can track your orders by going to the 'My Purchases' section under the 'MY' tab in the OneWave. Your orders are organised based on their current status.</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 OneWave. All rights reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
    </footer>

    <!-- Bootstrap JS with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.faq-item h3').forEach(item => {
            item.addEventListener('click', () => {
                const content = item.nextElementSibling;
                content.classList.toggle('show');
            });
        });
    </script>
</body>
</html>
