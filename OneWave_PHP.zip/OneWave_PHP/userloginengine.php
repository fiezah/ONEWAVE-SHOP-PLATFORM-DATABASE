<?php
session_start();
include('db_connection.php');

// Connection to the server
$conn = mysqli_connect("localhost", "root", "", "onewave");

if (!$conn) {
    die('ERROR: ' . mysqli_connect_error());
}

if (isset($_POST['login'])) {
    // Capture form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // SQL query to select user data from the user table
    $sql = "SELECT * FROM user WHERE username = ?";
    
    // Prepare the query
    $stmt = $conn->prepare($sql);
    
    // Bind parameters and execute the statement
    $stmt->bind_param("s", $username); // 's' means the parameter is a string
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        // Fetch the user data
        $user = $result->fetch_assoc();

        // Directly compare the submitted password with the stored password (plain text)
        if ($password === $user['password']) {
            // If password is correct, start a session and redirect to home.php
            $_SESSION['user_id'] = $user['id'];  // Assuming 'id' is the user's unique identifier
            header("Location: home.php");  // Redirect to home.php
            exit;  // Stop the script after redirection
        } else {
            // If password is incorrect
            echo "<script>alert('Invalid password!'); window.location.href='userlogin.php';</script>";
        }
    } else {
        // If user not found
        echo "<script>alert('User not found!'); window.location.href='userlogin.php';</script>";
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>