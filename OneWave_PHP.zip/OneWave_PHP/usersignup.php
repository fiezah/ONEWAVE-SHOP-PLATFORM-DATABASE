<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Sign Up</title>
    <!-- Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Import Pacifico font from Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet"> 
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }

        .form-container {
            max-width: 700px;
            margin: 100px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .form-container h1 {
            font-family: 'Pacifico', cursive;
            font-size: 40px;
            font-weight: 600;
            margin-bottom: 20px;
            margin-top: 40px;
            color: #17a2b8;
        }

        .form-container h4 {
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
            font-weight: bold;
        }

        .form-container input[type="text"],
        .form-container input[type="email"],
        .form-container input[type="tel"],
        .form-container input[type="password"],
        .form-container select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container button {
            width: 100%;
            padding: 12px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #138496;
        }

        .form-container a {
            color: #17a2b8;
            text-decoration: none;
            font-size: 14px;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #17a2b8;
            text-align: center;
            padding: 20px;
            margin-top: 50px;
            color: white;
            font-size: 17px;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>OneWave</h1>
    <h4>Sign Up your OneWave account now!</h4>
    <form action="usersignupengine.php" method="POST" onsubmit="return validateForm(event)">
        <input type="text" id="username" name="username" placeholder="Username" required><br>
        <input type="text" id="user_name" name="user_name" placeholder="Full Name" required><br>
        <input type="email" id="email" name="email" placeholder="Email" required><br>
        <input type="tel" id="phone" name="phone" placeholder="Phone Number" required pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" title="Phone number format: 123-456-7890"><br>
        <label for="gender">Gender:</label><br>
        <select id="gender" name="gender" required>
            <option value="Male">Male</option>
            <option value="Female" selected>Female</option>
            <option value="Other">Other</option>
        </select><br><br>
        <input type="password" id="password" name="password" placeholder="Password" required><br>
        <input type="password" id="confirmPassword" placeholder="Confirm Password" required><br>
        <button type="submit">Sign Up</button>
        <p class="message" id="message"></p>
    </form>

    <div class="info">
        Already have an account? <a href="userlogin.php">Login here</a>
    </div>
</div>

<footer>
    <p>© 2024 OneWave. All rights reserved. Privacy Policy | Terms of Service</p>
</footer>

<script>
    // Function to check if the passwords match before submitting the form
    function validateForm(event) {
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirmPassword").value;
        if (password !== confirmPassword) {
            document.getElementById("message").textContent = "Passwords do not match!";
            event.preventDefault();
            return false;
        }
        return true;
    }
</script>

</body>
</html>
