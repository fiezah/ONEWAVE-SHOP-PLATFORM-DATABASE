<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneWave Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
            font-family: 'Arial', sans-serif;
        }
        .checkout-container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .checkout-header {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .checkout-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 0;
        }
        .checkout-item:last-child {
            border-bottom: none;
        }
        .checkout-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }
        .checkout-item-details {
            flex-grow: 1;
            margin-left: 15px;
        }
        .checkout-item-title {
            font-size: 16px;
            margin: 0;
        }
        .checkout-item-price {
            font-size: 14px;
            color: #666;
        }
        .total-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }
        .payment-methods {
            margin-top: 30px;
        }
        .payment-methods label {
            margin-right: 20px;
        }
        .pay-btn {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .pay-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="checkout-container">
    <div class="checkout-header">Checkout</div>
    <div id="checkout-items">
        <!-- Checkout items will be dynamically loaded here -->
    </div>
    <div class="total-container">
        <span>Total: $<span id="total-amount">0.00</span></span>
    </div>

    <div class="payment-methods">
        <h5>Payment Method</h5>
        <div>
            <input type="radio" id="credit-card" name="payment" value="credit-card">
            <label for="credit-card">Credit Card</label>
            <input type="radio" id="paypal" name="payment" value="paypal">
            <label for="paypal">PayPal</label>
        </div>
    </div>

    <button class="pay-btn" id="pay-btn">Pay Now</button>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const checkoutItemsContainer = document.getElementById('checkout-items');
        const totalAmountEl = document.getElementById('total-amount');
        const payBtn = document.getElementById('pay-btn');

        // Fetch cart from localStorage
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Function to render checkout items
        function renderCheckout() {
            checkoutItemsContainer.innerHTML = '';  // Clear current checkout items
            let total = 0;
            cart.forEach(item => {
                if (item.selected) {
                    const checkoutItem = document.createElement('div');
                    checkoutItem.classList.add('checkout-item');
                    checkoutItem.innerHTML = `
                        <img src="${item.image || 'placeholder.jpg'}" alt="${item.name}" style="width: 80px; height: 80px;">
                        <div class="checkout-item-details">
                            <h5 class="checkout-item-title">${item.name}</h5>
                            <p class="checkout-item-price">$${item.price.toFixed(2)} x ${item.quantity}</p>
                        </div>
                    `;
                    checkoutItemsContainer.appendChild(checkoutItem);
                    total += item.price * item.quantity;
                }
            });
            totalAmountEl.textContent = total.toFixed(2);
        }

        // Handle the "Pay Now" button click
        payBtn.addEventListener('click', () => {
            const selectedPaymentMethod = document.querySelector('input[name="payment"]:checked');
            if (!selectedPaymentMethod) {
                alert('Please select a payment method.');
                return;
            }

            const paymentMethod = selectedPaymentMethod.value;
            // Prepare data to be sent to the PHP script
            const selectedItems = cart.filter(item => item.selected);

            if (selectedItems.length === 0) {
                alert('No items selected for checkout.');
                return;
            }

            fetch('checkoutEngine.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    checkout: true,
                    selected_items: selectedItems,
                    payment_method: paymentMethod
                })
            })
            .then(response => response.text())
            .then(data => {
                console.log(data); // Debugging
                alert('Order placed successfully!');
                localStorage.removeItem('cart'); // Clear the cart after checkout
                window.location.href = 'receipts.php'; // Redirect to a receipt page (optional)
            })
            .catch(error => {
                console.error('Error:', error);
                alert('There was an error processing your order. Please try again.');
            });
        });

        // Initialize checkout page
        renderCheckout();
    });
</script>

</body>
</html>
