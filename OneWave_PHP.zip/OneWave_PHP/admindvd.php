<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onewave";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert new record
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $sql = "INSERT INTO dvd (name, price, image) VALUES ('$name', '$price', '$image')";
    $conn->query($sql);
}

// Update record
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $sql = "UPDATE dvd SET name='$name', price='$price', image='$image' WHERE id='$id'";
    $conn->query($sql);
}

// Delete record
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM dvd WHERE id='$id'";
    $conn->query($sql);
}

// Search functionality
$searchResults = [];
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search_term'];
    $sql = "SELECT * FROM dvd WHERE name LIKE '%$searchTerm%'";
    $searchResults = $conn->query($sql);
}

// Fetch all records
$sql = "SELECT * FROM dvd";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DVD Management</title>
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script>
        // Function to populate the edit form with existing values
        function editRecord(id, name, price, image) {
            document.getElementById('editId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editPrice').value = price;
            document.getElementById('editImage').value = image;
            document.getElementById('editForm').style.display = 'block';
        }
    </script>
</head>
<body>
<header>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-navbar">
<div class="container">
    <a class="navbar-brand" href="dashboard.php">OneWave</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <!-- Shop Select Dropdown -->
            <li class="nav-item">
                <form class="form-inline my-2 my-lg-0 ml-3">
                    <select class="form-control" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                        <option value="">SELECT CATEGORY</option>
                        <option value="adminmerch.php">MERCH</option>
                        <option value="admindvd.php">DVD</option>
                        <option value="adminalbum.php">ALBUM</option>
                    </select>
                </form>
            </li>
            
            <!-- Currency Select Dropdown -->
            <li class="nav-item">
                <form class="form-inline my-2 my-lg-0 ml-3">
                    <select class="form-control" id="currencySelect">
                        <option value="USD" data-rate="1" data-symbol="$">USD</option>
                        <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                        <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                        <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                        <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                    </select>
                </form>
            </li>
        </ul>

        <!-- Log Out button for admin -->
        <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-info my-2 my-sm-0 mr-2" type="button" onclick="window.location.href='signingUp.php'">Log Out</button>
        </form>
    </div>
</div>
</nav>

</header>

    <div class="container">
        <h2>DVD MANAGEMENT</h2>

        <!-- Search form -->
        <form method="post">
            <input type="text" name="search_term" placeholder="Search DVD">
            <button type="submit" name="search" class="search-button">Search</button>
        </form>

        <!-- Display search results -->
        <?php if (isset($_POST['search']) && $searchResults->num_rows > 0) { ?>
            <h3>Search Results</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $searchResults->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><img src="<?php echo $row['image']; ?>" alt="Image" width="50"></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } ?>

        <!-- Display all DVDs -->
        <h3>DVD INVENTORY</h3>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><img src="<?php echo $row['image']; ?>" alt="Image" width="50"></td>
                        <td>
                            <button class="edit-button" onclick="editRecord('<?php echo $row['id']; ?>', '<?php echo $row['name']; ?>', '<?php echo $row['price']; ?>', '<?php echo $row['image']; ?>')">Edit</button>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete" class="delete-button">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Add new DVD form -->
        <div class="add-item-container">
            <h2>Add New Item</h2>
            <form method="post">
                <input type="text" name="name" placeholder="Item Name" required>
                <input type="number" name="price" placeholder="Item Price" required>
                <input type="text" name="image" placeholder="Item Image URL" required>
                <button type="submit" name="add" class="add-item-button">Add Item</button>
            </form>
        </div>
        
        <!-- Edit DVD form (hidden initially) -->
        <div id="editForm" style="display:none;">
            <h3>Edit DVD</h3>
            <form method="post">
                <input type="hidden" id="editId" name="id">
                <input type="text" id="editName" name="name" placeholder="Name" required>
                <input type="number" step="0.01" id="editPrice" name="price" placeholder="Price" required>
                <input type="text" id="editImage" name="image" placeholder="Image URL">
                <button type="submit" name="update" class="update-button">Update DVD</button>
            </form>
        </div>

    </div>

    <!-- Footer -->
	<footer class="bg-light text-dark mt-5">
	  <div class="container py-4">
		<div class="row">
		  <!-- Address Section -->
		  <div class="col-md-4">
			<h6>Company Information</h6>
			<address>
			  <strong>OneWave</strong><br>
			  6/1 Capricorn Street, <br>
			  Kuala Lumpur, Seoul, 56100<br>
			  <abbr title="Phone">P:</abbr> (123) 456-7890<br>
			  <abbr title="Email">E:</abbr> support@ohneulwave.com
			</address>
		  </div>

		  <!-- Useful Links -->
		  <div class="col-md-4">
			<h6>Useful Links</h6>
			<ul class="list-unstyled">
			  <li><a href="#">Terms of Service</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">FAQ</a></li>
			  <li><a href="#">Contact Us</a></li>
			</ul>
		  </div>

		  <!-- Social Media Links -->
		  <div class="col-md-4">
			<h6>Follow Us</h6>
			<ul class="list-unstyled">
			  <li><a href="https://www.instagram.com/twistntreatdotcom/">Instagram</a></li>
			  <li><a href="https://twitter.com">Twitter</a></li> <!-- Corrected Twitter link -->
			  <li><a href="https://facebook.com">Facebook</a></li> <!-- Corrected Facebook link -->
			</ul>
		  </div>
		</div>

		<div class="text-center mt-4">
		  <p class="mb-0">© 2024 OneWave. All rights reserved.</p>
		</div>
	  </div>
	</footer>

    <script src="path/to/currency.js" defer></script>
    <script>
        // Currency selector
		document.getElementById('currencySelect').addEventListener('change', function() {
			const selectedOption = this.options[this.selectedIndex];
            const rate = parseFloat(selectedOption.getAttribute('data-rate'));
            const symbol = selectedOption.getAttribute('data-symbol');
            const priceElements = document.querySelectorAll('.product-price');
			
			priceElements.forEach(function(element) {
				const originalPrice = parseFloat(element.getAttribute('data-original-price'));
                const convertedPrice = (originalPrice * rate).toFixed(2);
                element.textContent = `${symbol}${convertedPrice}`;
            });
        });
        </script>
</body>
</html>
<?php
$conn->close();
?>

<style>
/* Global Styles */
body {
    font-family: 'Roboto', sans-serif;
    background: #f5f5f5; /* Soft, light background for a dreamy effect */
    color: #333;
    margin: 0;
    padding: 0;
}

.navbar {
    padding: 0.5rem 1rem; /* Adjust padding to control the height */
    height: auto; /* Set height to auto to adapt */
}

.navbar-brand img {
    max-height: 40px; /* Adjust logo size as needed */
}

.navbar-nav .nav-item {
    padding: 0 0.5rem; /* Adjust padding between items */
}

.form-control {
    height: auto; /* Make sure dropdowns fit within the navbar */
    padding: 0.25rem 0.5rem; /* Reduce padding for a smaller appearance */
}

/* Main container */
.container {
    margin-top: 30px;
    padding: 0 15px; /* Added padding for container */
}

/* Heading */
h2 {
    color: #4a4a4a;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 20px;
}

/* Form */
input[type="text"], input[type="number"], select, button {
    font-size: 16px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ddd;
    margin-bottom: 15px;
    width: 100%;
    box-sizing: border-box;
    background-color: #f8f8f8;
}

input[type="text"]:focus, input[type="number"]:focus, select:focus {
    outline: none;
    border-color: #ffcc66;
    background-color: #fff;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 30px;
}

table th, table td {
    text-align: left;
    padding: 12px;
    font-size: 16px;
    color: #333;
}

table th {
    background-color: #f4f4f4;
    color: #666;
    font-weight: bold;
}

table td {
    background-color: #fff;
}

table tr:nth-child(even) td {
    background-color: #f9f9f9;
}

table td img {
    width: 60px;
    height: auto;
    border-radius: 5px;
}

/* Edit Form */
#editForm {
    background: rgba(0, 0, 0, 0.1);
    padding: 20px;
    border-radius: 8px;
    margin: 0 auto;
    width: 60%; /* Center width */
    text-align: center; /* Center the text and inline elements */
}

/* Center input fields */
#editForm input[type="text"],
#editForm input[type="number"] {
    width: 80%; /* Adjust width as needed */
    margin-bottom: 15px; /* Add space between inputs */
    display: block; /* Make input elements block-level */
    margin: 0 auto 15px auto; /* Center each input */
}

/* Search, Add, and Edit Buttons */
.search-button, .add-button, .edit-button {
    background: #17a2b8; /* Set to the requested color for search, add, and edit */
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.search-button:hover, .add-button:hover, .edit-button:hover {
    background-color: #138496; /* Hover color for search, add, and edit */
}

/* Delete Button (Pale Violet Red) */
.delete-button, .update-button {
    background: PaleVioletRed; /* PaleVioletRed color for delete */
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.delete-button:hover, .update-button:hover {
    background-color: #C71585; /* Darker shade of PaleVioletRed for hover */
}

/* Form Container for Add Item */
.add-item-container {
    width: 1100px; /* Set width to match Edit DVD */
    margin: 0 auto; /* Center the form */
    padding: 20px; /* Add padding for spacing */
    background-color: #f0f0f0; /* Optional: add background color for better visibility */
    border-radius: 8px; /* Rounded corners for a consistent look */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Optional: add shadow for depth */
}

/* Form Elements for Add Item */
.add-item-container input[type="text"], 
.add-item-container input[type="number"] {
    font-size: 16px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ddd;
    margin-bottom: 15px;
    width: 100%; /* Full width */
    box-sizing: border-box;
    background-color: #f8f8f8;
}

.add-item-container input[type="text"]:focus, 
.add-item-container input[type="number"]:focus {
    outline: none;
    border-color: #ffcc66;
    background-color: #fff;
}

/* Add Item Button */
.add-item-button {
    background-color: #17a2b8; /* Consistent color */
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 5px;
    width: 100%; /* Full width */
    transition: background-color 0.3s ease;
}

.add-item-button:hover {
    background-color: #138496; /* Darker shade on hover */
}

/* Responsive Design for Add Item Container */
@media (max-width: 767px) {
    .add-item-container {
        width: 90%; /* Adjust width for smaller screens */
        padding: 15px; /* Reduce padding */
    }

    .add-item-container h2 {
        font-size: 20px; /* Adjust heading size */
    }

    .add-item-container input[type="text"], 
    .add-item-container input[type="number"], 
    .add-item-container .add-item-button {
        font-size: 14px; /* Adjust input and button size */
        padding: 8px;
    }
}

/* Footer */
footer {
    background-color: #f1f1f1;
    color: #333;
    padding: 40px 0;
    margin-top: 50px;
}

footer h6 {
    font-weight: bold;
    font-size: 18px;
}

footer .list-unstyled {
    padding: 0;
    list-style: none;
}

footer .list-unstyled li {
    margin-bottom: 10px;
}

footer .list-unstyled li a {
    color: #666;
    text-decoration: none;
}

footer .list-unstyled li a:hover {
    color: #ffcc66;
}

/* Responsive Design */
@media (max-width: 767px) {
    .navbar {
        text-align: center;
    }

    .navbar .navbar-nav {
        margin-top: 10px;
    }

    .container {
        padding: 15px; /* Padding for mobile view */
    }

    table {
        font-size: 14px;
    }

    h2 {
        font-size: 22px;
    }

    input[type="text"], input[type="number"], select, button {
        font-size: 14px; /* Adjust form inputs for smaller screens */
        padding: 8px;
    }

    .search-button, .add-button, .edit-button {
        width: 100%; /* Make buttons full width on mobile */
        padding: 10px 15px;
    }

    #editForm input[type="text"], #editForm input[type="number"] {
        width: 100%; /* Make inputs full width in edit form */
        margin-right: 0;
        margin-bottom: 10px; /* Space between inputs */
    }
}
</style>