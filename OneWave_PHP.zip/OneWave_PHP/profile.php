<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OneWave Project</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .profile-container {
            display: flex;
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }

        .sidebar {
            width: 250px;
            background-color: #ffffff;
            border-right: 1px solid #e0e0e0;
            padding: 20px;
        }

        .sidebar-pic {
            width: 100px; /* Width of the image */
            height: 100px; /* Height of the image */
            border-radius: 50%; /* To make it circular */
            object-fit: cover; /* Ensures the image maintains its aspect ratio */
        }

        .profile-main {
            flex: 1;
            padding: 20px;
            background-color: #ffffff;
        }

        .profile-main h1 {
            font-size: 24px;
        }

        form label {
            font-weight: bold;
            margin-top: 10px;
        }

        form input[type="text"],
        form input[type="email"],
        form input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
	
<header>

    <!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-navbar">
    <div class="container">
        <a class="navbar-brand" href="home.php">OneWave</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <!-- Shop Select Dropdown -->
                <li class="nav-item">
                    <form class="form-inline my-2 my-lg-0 ml-3">
                        <select class="form-control" id="ShopSelect" onchange="if (this.value) window.location.href=this.value;">
                            <option value="">SELECT CATEGORY</option>
                            <option value="merch.php">MERCH</option>
                            <option value="dvd.php">DVD</option>
                            <option value="album.php">ALBUM</option>
                        </select>
                    </form>
                </li>
                
                <!-- Currency Select Dropdown -->
                <li class="nav-item">
                    <form class="form-inline my-2 my-lg-0 ml-3">
                        <select class="form-control" id="currencySelect">
                            <option value="USD" data-rate="1" data-symbol="$">USD</option>
                            <option value="EUR" data-rate="0.85" data-symbol="€">EUR</option>
                            <option value="KRW" data-rate="1300" data-symbol="₩">KRW</option>
                            <option value="JPY" data-rate="110" data-symbol="¥">JPY</option>
                            <option value="MYR" data-rate="4.5" data-symbol="MYR">MYR</option>
                        </select>
                    </form>
                </li>
            </ul>

			<!-- Shopping Cart Icon -->
			<a href="cart.php" class="mr-3">
                    <i class="fas fa-shopping-cart" style="font-size: 24px; color: #17a2b8;"></i>
                </a>

            <!-- Menu Dropdown -->
            <form class="form-inline my-2 my-lg-0 ml-3">
                <select class="form-control" id="menuDropdown" onchange="if (this.value) window.location.href=this.value;">
                    <option value="">MY</option>
                    <option value="purchase.php">PURCHASES</option>
                    <option value="profile.php">PROFILE</option>
					<option value="#" disabled><hr style="margin: 3px 0;"></option>
                    <option value="mainPage.php">LOG OUT</option>
					<option value="#" disabled style="padding-bottom: 10px;"></option>
                </select>
            </form>
        </div>
    </div>
</nav>

</header>
	
<body>

<div class="profile-container">
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="profile-info">
            <!-- Sidebar Username Updated -->
            <img src="images/PROFILE_PIC.png" alt="Profile Picture" class="sidebar-pic">
            <p class="username" id="sidebarUsername">Loading...</p> <!-- Update dynamically -->
            <a href="#" class="edit-profile">Edit Profile</a>
        </div>
        <nav>
            <ul>
                <li class="active">Profile</li>
                <li>Banks & Cards</li>
                <li>Addresses</li>
                <li>Change Password</li>
                <li>Notification Settings</li>
                <li>Privacy Settings</li>
            </ul>
        </nav>
    </div>

    <div class="profile-main">
        <h1>Profile</h1>
        <form>
            <label for="name">Full Name:</label>
            <input type="text" id="name" readonly><br>

            <label for="email">Email:</label>
            <input type="email" id="email" readonly><br>

            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" readonly><br>

            <label>Gender:</label><br>
            <input type="radio" id="male" name="gender" value="Male" disabled> Male
            <input type="radio" id="female" name="gender" value="Female" disabled> Female
            <input type="radio" id="other" name="gender" value="Other" disabled> Other<br><br>
        </form>
    </div>
</div>

    <!-- Footer -->
	<footer class="bg-light text-center py-4">
		<div class="container">
			<p class="text-muted mb-0">© 2024 OneWave. All rights reserved.</p>
		</div>
	</footer>
	
	<!-- My custom JavaScript -->
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<script>
    // Profile page script
    const username = localStorage.getItem("username") || "Not set";
    const name = localStorage.getItem("name") || "Not set";
    const email = localStorage.getItem("email") || "Not set";
    const phone = localStorage.getItem("phone") || "Not set";
    const gender = localStorage.getItem("gender") || "Female"; 

    document.getElementById("sidebarUsername").innerText = username;
    document.getElementById("name").value = name;
    document.getElementById("email").value = email;
    document.getElementById("phone").value = phone;

    if (gender === "Male") {
        document.getElementById("male").checked = true;
    } else if (gender === "Female") {
        document.getElementById("female").checked = true;
    } else if (gender === "Other") {
        document.getElementById("other").checked = true;
    }
</script>

</body>
</html>
