<?php
session_start();
include('db_connection.php');

// Connection to the server
$conn = mysqli_connect("localhost", "root", "", "onewave");

if (!$conn) {
    die('ERROR: ' . mysqli_connect_error());
}

if (isset($_POST['login'])) {
    // Capture form data
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // SQL query to select admin data from the admin table
    $sql = "SELECT * FROM admin WHERE email = ?";
    
    // Prepare the query
    $stmt = $conn->prepare($sql);
    
    // Bind parameters and execute the statement
    $stmt->bind_param("s", $email); // 's' means the parameter is a string
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();

    // Check if the admin exists
    if ($result->num_rows > 0) {
        // Fetch the admin data
        $admin = $result->fetch_assoc();

        // Directly compare the submitted password with the stored password (plain text)
        if ($password === $admin['password']) {
            // If password is correct, start a session and redirect to home.php
            $_SESSION['admin_id'] = $admin['id'];  // Assuming 'id' is the admin's unique identifier
            header("Location: dashboard.php");  // Redirect to home.php
            exit;  // Stop the script after redirection
        } else {
            // If password is incorrect
            echo "<script>alert('Invalid password!'); window.location.href='adminlogin.php';</script>";
        }
    } else {
        // If admin not found
        echo "<script>alert('Admin not found!'); window.location.href='adminlogin.php';</script>";
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>
